self.description = "Test command line option (-S --help)"

self.args = "-S --help"

self.addrule("PACMAN_RETCODE=0")
